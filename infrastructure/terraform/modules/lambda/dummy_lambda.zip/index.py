def handler(event, context):
    print('Thumbnail processor invoked:', event)
    return {'statusCode': 200}